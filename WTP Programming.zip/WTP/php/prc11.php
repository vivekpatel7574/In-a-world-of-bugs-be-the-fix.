<!-- 11. PHP Control Structures: Create a PHP script that uses if-else and switch-case statements for
    decision-making. -->


    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Control Structures Example</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .result {
            margin-top: 20px;
            font-size: 1.2em;
        }
    </style>
</head>
<body>

    <h2>PHP If-Else and Switch-Case Example</h2>

    <?php
    
    $age = 25;  

    if ($age < 18) {
        echo "<p>You are a minor.</p>";
    } elseif ($age >= 18 && $age <= 60) {
        echo "<p>You are an adult.</p>";
    } else {
        echo "<p>You are a senior citizen.</p>";
    }

    $dayOfWeek = "Monday";  

    switch ($dayOfWeek) {
        case "Monday":
            echo "<p>Start of the workweek! Let's be productive!</p>";
            break;
        case "Tuesday":
            echo "<p>Keep the momentum going!</p>";
            break;
        case "Wednesday":
            echo "<p>Halfway through the week!</p>";
            break;
        case "Thursday":
            echo "<p>Almost there!</p>";
            break;
        case "Friday":
            echo "<p>It's Friday! Time to wrap things up!</p>";
            break;
        case "Saturday":
            echo "<p>Enjoy your weekend!</p>";
            break;
        case "Sunday":
            echo "<p>Relax and recharge for the week ahead!</p>";
            break;
        default:
            echo "<p>Invalid day input!</p>";
    }
    ?>

</body>
</html>
