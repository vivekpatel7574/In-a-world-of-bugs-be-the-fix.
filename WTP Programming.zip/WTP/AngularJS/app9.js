

var app = angular.module('app', []);

app.controller('AppController', function($scope) {
   
    $scope.isVisible = true;  
    $scope.clickCount = 0;    
    
    $scope.toggleVisibility = function() {
        $scope.isVisible = !$scope.isVisible;  
    };
    
    $scope.incrementCounter = function() {
        $scope.clickCount++;  
    };
});
