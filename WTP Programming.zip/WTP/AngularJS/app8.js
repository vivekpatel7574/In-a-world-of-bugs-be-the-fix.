
var app = angular.module('todoApp', []);


app.controller('TodoController', function($scope) {
   
    $scope.tasks = [];

    
    $scope.addTask = function() {
        if ($scope.newTask) {
            $scope.tasks.push($scope.newTask); 
            $scope.newTask = ''; 
        }
    };

    $scope.removeTask = function(index) {
        $scope.tasks.splice(index, 1); 
    };
});


app.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown", function (event) {
            if (event.keyCode === 13) { 
                scope.$apply(attrs.ngEnter);
            }
        });
    };
});
