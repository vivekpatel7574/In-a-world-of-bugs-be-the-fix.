
// 44. Write a program to read, print and addition of two Matrices using pointer and user define
//     functions.


#include <stdio.h>

#define MAX 3  // Define the size of the matrix

// Function to read matrix elements
void readMatrix(int *matrix, int rows, int cols) {
    printf("Enter elements of the matrix (%dx%d):\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("Enter element [%d][%d]: ", i+1, j+1);
            scanf("%d", (matrix + i * cols + j));  // Access matrix elements using pointer arithmetic
        }
    }
}

// Function to print matrix elements
void printMatrix(int *matrix, int rows, int cols) {
    printf("Matrix (%dx%d):\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", *(matrix + i * cols + j));  // Dereference pointer to access elements
        }
        printf("\n");
    }
}

// Function to add two matrices and store the result in a third matrix
void addMatrices(int *matrix1, int *matrix2, int *result, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            *(result + i * cols + j) = *(matrix1 + i * cols + j) + *(matrix2 + i * cols + j);
        }
    }
}

int main() {
    int matrix1[MAX][MAX], matrix2[MAX][MAX], result[MAX][MAX];

    // Read matrices
    readMatrix(&matrix1[0][0], MAX, MAX);
    readMatrix(&matrix2[0][0], MAX, MAX);

    // Print matrices
    printf("\nMatrix 1:\n");
    printMatrix(&matrix1[0][0], MAX, MAX);

    printf("\nMatrix 2:\n");
    printMatrix(&matrix2[0][0], MAX, MAX);

    // Add matrices
    addMatrices(&matrix1[0][0], &matrix2[0][0], &result[0][0], MAX, MAX);

    // Print result
    printf("\nResultant Matrix after addition:\n");
    printMatrix(&result[0][0], MAX, MAX);

    return 0;
}
