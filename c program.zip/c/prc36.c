
// 36. Write a program to read structure elements from keyboard.


#include <stdio.h>

// Define a structure
struct Student {
    char name[50];
    int age;
    float marks;
};

int main() {
    struct Student s; // Declare a variable of type struct Student


    printf("Enter student's name: ");
    fgets(s.name, sizeof(s.name), stdin); t

    printf("Enter student's age: ");
    scanf("%d", &s.age); 

    printf("Enter student's marks: ");
    scanf("%f", &s.marks); 


    printf("\nStudent Details:\n");
    printf("Name: %s", s.name);
    printf("Age: %d\n", s.age);
    printf("Marks: %.2f\n", s.marks);

    return 0;
}
