
// 32. Write a program that defines a function to add first n numbers.

#include <stdio.h>

// Function to calculate the sum of the first n numbers
int sumOfNumbers(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i; // Add current number to the sum
    }
    return sum;
}

int main() {
    int n;


    printf("Enter the value of n: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Please enter a positive number.\n");
    } else {
        
        // Call the function and display the result
        int result = sumOfNumbers(n);
        printf("The sum of the first %d numbers is: %d\n", n, result);
    }

    return 0;
}
