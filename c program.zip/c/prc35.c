
// 35. Write a function that will scan a character string passed as an argument and convertall
//     lowercase character into their uppercase equivalents


#include <stdio.h>
#include <ctype.h> // Required for toupper()


void convertToUppercase(char str[]) {
    int i = 0;
    while (str[i] != '\0') { // Loop until end of string
        if (islower(str[i])) {
            str[i] = toupper(str[i]); 
        }
        i++;
    }
}

int main() {
    char str[100];

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin); // Use fgets to handle spaces in the input

    convertToUppercase(str);

    printf("String after conversion: %s\n", str);

    return 0;
}
