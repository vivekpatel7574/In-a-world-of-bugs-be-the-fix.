
// 50. Program for deleting the spaces from the contents of file.


#include <stdio.h>
#include <stdlib.h>

void removeSpacesFromFile(char *inputFile, char *outputFile) {
    FILE *inFile = fopen(inputFile, "r");  // Open the input file in read mode
    if (inFile == NULL) {
        printf("Error opening file: %s\n", inputFile);
        exit(1);
    }

    FILE *outFile = fopen(outputFile, "w");  // Open the output file in write mode
    if (outFile == NULL) {
        printf("Error opening output file: %s\n", outputFile);
        fclose(inFile);  // Close the input file before exiting
        exit(1);
    }

    char ch;

    // Read the file character by character
    while ((ch = fgetc(inFile)) != EOF) {
        // If the character is not a space, write it to the output file
        if (ch != ' ') {
            fputc(ch, outFile);
        }
    }

    printf("Spaces have been removed and the content has been written to %s.\n", outputFile);

    // Close both the input and output files
    fclose(inFile);
    fclose(outFile);
}

int main() {
    char inputFile[] = "input.txt";  // Name of the input file
    char outputFile[] = "output.txt";  // Name of the output file

    // Call the function to remove spaces from the file content
    removeSpacesFromFile(inputFile, outputFile);

    return 0;
}
