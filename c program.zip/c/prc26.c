// 26. Write a C program to read and store the roll no and marks of 20 students using array.


#include <stdio.h>

#define TOTAL_STUDENTS 20  

int main() {
    int roll_no[TOTAL_STUDENTS];  // Array to store roll numbers
    float marks[TOTAL_STUDENTS];   // Array to store marks
    int i;

    printf("Enter the roll number and marks for %d students:\n", TOTAL_STUDENTS);
    for (i = 0; i < TOTAL_STUDENTS; i++) {
        printf("Enter Roll Number of Student %d: ", i + 1);
        scanf("%d", &roll_no[i]);  
        printf("Enter Marks of Student %d: ", i + 1);
        scanf("%f", &marks[i]);    
    }

    printf("\nRoll Number and Marks of Students:\n");
    printf("Roll No\tMarks\n");
    for (i = 0; i < TOTAL_STUDENTS; i++) {
        printf("%d\t\t%.2f\n", roll_no[i], marks[i]);
    }

    return 0;
}
