// 11. Write a program to read marks from keyboard and your program should displayequivalent
//     grade according to following table(if else ladder)
//     Marks Grade
//     100 - 80 Distinction
//     79 - 60 First Class
//     59 - 40 Second Class
//     < 40 Fail


#include <stdio.h>

int main() {
    int marks;

    printf("Enter the marks: ");
    scanf("%d", &marks);

    // Determine grade
    if (marks >= 80 && marks <= 100) {
        printf("Grade: Distinction\n");
    } else if (marks >= 60 && marks < 80) {
        printf("Grade: First Class\n");
    } else if (marks >= 40 && marks < 60) {
        printf("Grade: Second Class\n");
    } else if (marks >= 0 && marks < 40) {
        printf("Grade: Fail\n");
    } else {
        printf("Invalid marks entered.\n");
    }

    return 0;
}
