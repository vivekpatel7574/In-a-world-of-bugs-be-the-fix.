
// 40. Write a program to print address of variable using pointer.

#include <stdio.h>

int main() {
    int num = 10;       
    int *ptr = &num;      // Declare a pointer and assign the address of num to it


    printf("Value of num: %d\n", num);
    printf("Address of num: %p\n", &num);  // Directly print the address of num
    printf("Address of num using pointer: %p\n", ptr);  // Print the address using pointer

    return 0;
}
