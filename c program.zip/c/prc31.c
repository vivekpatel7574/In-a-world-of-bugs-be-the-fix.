
// 31. Write a program to convert string into upper case.


#include <stdio.h>
#include <ctype.h> // Required for toupper()

void convertToUppercase(char str[]) {
    int i = 0;
    while (str[i] != '\0') {
        str[i] = toupper(str[i]); // Convert each character to uppercase
        i++;
    }
}

int main() {
    char str[100];

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin); // Use fgets to include spaces

    // Convert to uppercase
    convertToUppercase(str);

    printf("String in uppercase: %s\n", str);

    return 0;
}
