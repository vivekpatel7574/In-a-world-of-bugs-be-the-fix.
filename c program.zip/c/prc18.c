// 18. Write a program to calculate average and total of 5 students for 3 subjects (use nested for loops)


#include <stdio.h>

int main() {
    int marks[5][3]; 
    int total[5];    
    float average[5]; 

    for (int i = 0; i < 5; i++) {
        printf("Enter marks for Student %d:\n", i + 1);
        total[i] = 0; // Initialize total for each student

        for (int j = 0; j < 3; j++) {
            printf("  Subject %d: ", j + 1);
            scanf("%d", &marks[i][j]);
            total[i] += marks[i][j]; // Add to total
        }

        average[i] = total[i] / 3.0; // Calculate average
    }

    printf("\nStudent-wise Total and Average Marks:\n");
    for (int i = 0; i < 5; i++) {
        printf("Student %d: Total = %d, Average = %.2f\n", i + 1, total[i], average[i]);
    }

    return 0;
}
