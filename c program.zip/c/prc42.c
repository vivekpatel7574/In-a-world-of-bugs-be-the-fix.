
// 42. Write a C program to print the address of character and the character of string usingpointer.

#include <stdio.h>

int main() {
    char str[] = "Hello";  // Declare a string (array of characters)
    char *ptr = str;       // Declare a pointer and initialize it to the address of the string


    printf("Address of first character: %p\n", ptr);
    printf("Character at the address: %c\n", *ptr);


    printf("Addresses and characters of the string:\n");
    for (int i = 0; str[i] != '\0'; i++) {
        printf("Address of str[%d]: %p, Character: %c\n", i, ptr + i, *(ptr + i));
    }

    return 0;
}
