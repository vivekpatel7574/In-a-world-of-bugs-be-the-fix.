// 7. Write a C program to find that the accepted number is Negative, Positive or Zero.

#include <stdio.h>

int main() {
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    // Check the number
    if (number > 0) {
        printf("The number is Positive.\n");
    } else if (number < 0) {
        printf("The number is Negative.\n");
    } else {
        printf("The number is Zero.\n");
    }

    return 0;
}
