// 21. Write a program to evaluate the series 1^2+2^2+3^2+......+n^2


#include <stdio.h>

int main() {
    int n, sum = 0;

    printf("Enter the value of n: ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        sum += i * i;  // Add the square of i to the sum
    }

    printf("The sum of squares from 1 to %d is: %d\n", n, sum);

    return 0;
}
