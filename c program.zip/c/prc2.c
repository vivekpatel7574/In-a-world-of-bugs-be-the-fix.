// 2. Write a program to find area of triangle(a=h*b*.5)
//         a = area h = height b = base.

#include <stdio.h>

int main() {
    float base, height, area;

    printf("Enter the base of the triangle: ");
    scanf("%f", &base);
    printf("Enter the height of the triangle: ");
    scanf("%f", &height);

    // Calculate the area
    area = 0.5 * base * height;

    printf("The area of the triangle is: %.2f\n", area);

    return 0;
}
