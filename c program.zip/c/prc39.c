
// 39. Design a structure student_record to contain name, branch and total marks obtained. Develop a
//     program to read data for 10 students in a class and print them.


#include <stdio.h>


struct student_record {
    char name[50];
    char branch[30];
    int total_marks;
};

int main() {
    struct student_record students[10]; // Array of structures for 10 students


    for (int i = 0; i < 10; i++) {
        printf("Enter details for student %d:\n", i + 1);

        printf("Name: ");
        getchar(); 
        fgets(students[i].name, sizeof(students[i].name), stdin);

        printf("Branch: ");
        fgets(students[i].branch, sizeof(students[i].branch), stdin);

        printf("Total Marks: ");
        scanf("%d", &students[i].total_marks);

        printf("\n");
    }

    printf("Details of Students:\n");
    printf("---------------------------------------------------\n");
    for (int i = 0; i < 10; i++) {
        printf("Student %d:\n", i + 1);
        printf("Name: %s", students[i].name);
        printf("Branch: %s", students[i].branch);
        printf("Total Marks: %d\n\n", students[i].total_marks);
    }

    return 0;
}
