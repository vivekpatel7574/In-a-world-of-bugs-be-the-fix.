
// 41. Write a C program to swap the two values using pointers.

#include <stdio.h>

void swap(int *x, int *y) {
    int temp = *x;  // Temporarily store the value of *x
    *x = *y;         // Assign the value of *y to *x
    *y = temp;       // Assign the temporarily stored value to *y
}

int main() {
    int a = 5, b = 10;

    printf("Before swapping:\n");
    printf("a = %d, b = %d\n", a, b);

    // Call swap function with the addresses of a and b
    swap(&a, &b);

    printf("After swapping:\n");
    printf("a = %d, b = %d\n", a, b);

    return 0;
}
