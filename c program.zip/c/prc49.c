
// 49. Write a program to merge two files into the third file.

#include <stdio.h>
#include <stdlib.h>

void mergeFiles(char *file1, char *file2, char *outputFile) {
    FILE *f1 = fopen(file1, "r");  // Open the first file in read mode
    if (f1 == NULL) {
        printf("Error opening file: %s\n", file1);
        exit(1);
    }

    FILE *f2 = fopen(file2, "r");  // Open the second file in read mode
    if (f2 == NULL) {
        printf("Error opening file: %s\n", file2);
        fclose(f1);  // Close the first file before exiting
        exit(1);
    }

    FILE *out = fopen(outputFile, "w");  // Open the output file in write mode
    if (out == NULL) {
        printf("Error opening output file: %s\n", outputFile);
        fclose(f1);  // Close the first file
        fclose(f2);  // Close the second file
        exit(1);
    }

    char ch;

    // Copy content from the first file to the output file
    while ((ch = fgetc(f1)) != EOF) {
        fputc(ch, out);
    }

    // Copy content from the second file to the output file
    while ((ch = fgetc(f2)) != EOF) {
        fputc(ch, out);
    }

    printf("Files have been merged successfully into %s.\n", outputFile);

    // Close all opened files
    fclose(f1);
    fclose(f2);
    fclose(out);
}

int main() {
    char file1[] = "file1.txt";  // Name of the first file
    char file2[] = "file2.txt";  // Name of the second file
    char outputFile[] = "mergedFile.txt";  // Name of the output file

    // Call the function to merge the files
    mergeFiles(file1, file2, outputFile);

    return 0;
}
