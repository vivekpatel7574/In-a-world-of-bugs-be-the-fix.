
// 47. Write a program to accept the contents from the user and store it in the file one line at a time and
//     print the contents of the file.


#include <stdio.h>
#include <stdlib.h>

void writeToFile() {
    FILE *file = fopen("user_input.txt", "w");  // Open file in write mode
    if (file == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }

    char line[100];
    printf("Enter text to be stored in the file (Type 'exit' to stop):\n");

    // Accept user input line by line and write it to the file
    while (1) {
        printf("Enter line: ");
        fgets(line, sizeof(line), stdin);  // Read a line from the user
        
        // If the user types "exit", break the loop
        if (strncmp(line, "exit", 4) == 0) {
            break;
        }

        fprintf(file, "%s", line);  // Write the line to the file
    }

    fclose(file);  // Close the file
}

void printFileContents() {
    FILE *file = fopen("user_input.txt", "r");  // Open file in read mode
    if (file == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }

    char ch;
    printf("\nContents of the file:\n");
    // Read and print the file content character by character
    while ((ch = fgetc(file)) != EOF) {
        putchar(ch);  // Print each character
    }

    fclose(file);  
}

int main() {
    writeToFile();    // Call function to accept user input and store in the file
    printFileContents();  // Call function to print the contents of the file

    return 0;
}
