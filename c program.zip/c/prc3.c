// 3. Write a program to calculate simple interest (i = (p*r*n)/100 )
//      i = Simple interest p= Principal amount r = Rate of interest n = Number of years.

#include <stdio.h>

int main() {
    float principal, rate, years, interest;

    printf("Enter the principal amount: ");
    scanf("%f", &principal);
    printf("Enter the rate of interest: ");
    scanf("%f", &rate);
    printf("Enter the number of years: ");
    scanf("%f", &years);

    interest = (principal * rate * years) / 100;

    printf("The simple interest is: %.2f\n", interest);

    return 0;
}
