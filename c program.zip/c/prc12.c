// 12. Write a c program to prepare pay slip using following data.Da = 10% of basic, Hra = 7.50% of 
//     basic, Ma = 300, Pf = 12.50% of basic, Gross = basic + Da + Hra + Ma, Nt = Gross – Pf.

#include <stdio.h>

int main() {
    float basic, da, hra, ma, pf, gross, net;

    printf("Enter the basic salary: ");
    scanf("%f", &basic);

    // Calculate components
    da = basic * 0.10;       
    hra = basic * 0.075;    
    ma = 300;                
    pf = basic * 0.125;      
    gross = basic + da + hra + ma; 
    net = gross - pf;       

    printf("\n----- Pay Slip -----\n");
    printf("Basic Salary      : %.2f\n", basic);
    printf("Dearness Allowance (DA): %.2f\n", da);
    printf("House Rent Allowance (HRA): %.2f\n", hra);
    printf("Medical Allowance (MA): %.2f\n", ma);
    printf("Provident Fund (PF): %.2f\n", pf);
    printf("Gross Salary      : %.2f\n", gross);
    printf("Net Salary        : %.2f\n", net);

    return 0;
}
