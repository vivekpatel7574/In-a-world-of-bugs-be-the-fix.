
// 37. Define a structure type struct personal that would contain person name, joining date and salary
//     using this structure to read this information of 5 people and print the same on screen.


#include <stdio.h>

struct personal {
    char name[50];
    char joiningDate[15];
    float salary;
};

int main() {
    struct personal people[5]; // Array of structures for 5 people

    for (int i = 0; i < 5; i++) {
        printf("Enter details for person %d:\n", i + 1);

        printf("Name: ");
        getchar(); // Clear newline from the input buffer
        fgets(people[i].name, sizeof(people[i].name), stdin);

        printf("Joining Date (DD/MM/YYYY): ");
        fgets(people[i].joiningDate, sizeof(people[i].joiningDate), stdin);

        printf("Salary: ");
        scanf("%f", &people[i].salary);

        printf("\n");
    }

    printf("Details of 5 People:\n");
    printf("---------------------------------------------------\n");
    for (int i = 0; i < 5; i++) {
        printf("Person %d:\n", i + 1);
        printf("Name: %s", people[i].name);
        printf("Joining Date: %s", people[i].joiningDate);
        printf("Salary: %.2f\n\n", people[i].salary);
    }

    return 0;
}
