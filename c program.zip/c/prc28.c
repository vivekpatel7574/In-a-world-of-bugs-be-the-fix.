// 28. Write a program to sort given array in ascending order.


#include <stdio.h>

#define SIZE 10  

void bubbleSort(int arr[], int size) {
    int i, j, temp;

    for (i = 0; i < size - 1; i++) {
        for (j = 0; j < size - i - 1; j++) {
            
            if (arr[j] > arr[j + 1]) {
                
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int arr[SIZE];  
    int i;

    printf("Enter %d elements:\n", SIZE);
    for (i = 0; i < SIZE; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

    // Call bubbleSort to sort the array in ascending order
    bubbleSort(arr, SIZE);

    printf("\nSorted array in ascending order:\n");
    for (i = 0; i < SIZE; i++) {
        printf("%d ", arr[i]);
    }

    printf("\n");

    return 0;
}
