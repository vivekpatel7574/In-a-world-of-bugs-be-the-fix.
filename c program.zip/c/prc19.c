// 19. Read five persons height and weight and count the number of person having height greater
//     than 170 and weight less than 50,


#include <stdio.h>

int main() {
    float height[5], weight[5];
    int count = 0;

    for (int i = 0; i < 5; i++) {
        printf("Enter height (in cm) and weight (in kg) for Person %d:\n", i + 1);
        printf("  Height: ");
        scanf("%f", &height[i]);
        printf("  Weight: ");
        scanf("%f", &weight[i]);

        // Check condition: height > 170 and weight < 50
        if (height[i] > 170 && weight[i] < 50) {
            count++;
        }
    }

    printf("\nNumber of persons with height > 170 cm and weight < 50 kg: %d\n", count);

    return 0;
}
