
// 38. Define structure data type called time_struct containing three member’s integer hour, integer
//     minute and integer second. Develop a program that would assign values to the individual number
//     and display the time in the following format: 16: 40:51


#include <stdio.h>


struct time_struct {
    int hour;
    int minute;
    int second;
};

int main() {
    struct time_struct time; // Declare a variable of type time_struct

    // Assign values to the structure members
    printf("Enter hour (0-23): ");
    scanf("%d", &time.hour);

    printf("Enter minute (0-59): ");
    scanf("%d", &time.minute);

    printf("Enter second (0-59): ");
    scanf("%d", &time.second);

    // Validate the input values
    if (time.hour < 0 || time.hour > 23 || 
        time.minute < 0 || time.minute > 59 || 
        time.second < 0 || time.second > 59) {
        printf("Invalid time entered!\n");
    } else {
        // Display the time in the format HH:MM:SS
        printf("The time is: %02d:%02d:%02d\n", time.hour, time.minute, time.second);
    }

    return 0;
}
