
// 43. Write a program to access elements using pointer.

#include <stdio.h>

int main() {
    int arr[] = {10, 20, 30, 40, 50};  // Declare and initialize an array
    int *ptr = arr;  // Pointer to the first element of the array


    printf("Array elements using pointer:\n");
    for (int i = 0; i < 5; i++) {
        printf("Element at index %d: %d\n", i, *(ptr + i));  
    }

    return 0;
}
