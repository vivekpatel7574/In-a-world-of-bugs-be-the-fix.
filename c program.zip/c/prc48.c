
// 48. Read a text file which name is given in command line and print the total number of character in
//     each line and total number of lines in a file.


#include <stdio.h>
#include <stdlib.h>

void countCharsAndLines(char *filename) {
    FILE *file = fopen(filename, "r");  // Open the file in read mode
    if (file == NULL) {
        printf("Error opening file: %s\n", filename);
        exit(1);
    }

    int lineCount = 0;
    int charCount;
    char ch;

    // Read the file line by line
    while (!feof(file)) {
        lineCount++;  // Increment line count
        charCount = 0;  // Reset character count for the current line

        // Count characters in the current line
        while ((ch = fgetc(file)) != EOF && ch != '\n') {
            charCount++;  // Increment character count for each character in the line
        }

        // Print the character count for the current line
        printf("Line %d: %d characters\n", lineCount, charCount);
    }

    printf("\nTotal number of lines: %d\n", lineCount);

    fclose(file);  
}

int main(int argc, char *argv[]) {
    if (argc != 2) {  // Check if the user has provided a file name
        printf("Usage: %s <filename>\n", argv[0]);
        exit(1);
    }

    // Call the function to count characters and lines in the file
    countCharsAndLines(argv[1]);

    return 0;
}
