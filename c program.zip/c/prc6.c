// 6. Write a program to compute Fahrenheit from centigrade (f=1.8*c +32).

#include <stdio.h>

int main() {
    float celsius, fahrenheit;

    printf("Enter temperature in Celsius: ");
    scanf("%f", &celsius);

    // Calculate Fahrenheit
    fahrenheit = 1.8 * celsius + 32;

    printf("Temperature in Fahrenheit: %.2f°F\n", fahrenheit);

    return 0;
}
