
// 46. Write a program to read n integer number from keyboard and store them into a file All.txt. Read
//     All.txt file, separate even and odd numbers and store them into files Even.txt and Odd.txt
//     respectively and display contents of all the three files.

#include <stdio.h>
#include <stdlib.h>

void writeToFile(int *arr, int n) {
    FILE *file = fopen("All.txt", "w");  // Open the file in write mode
    if (file == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }

    for (int i = 0; i < n; i++) {
        fprintf(file, "%d\n", *(arr + i));  // Write each number to the file
    }

    fclose(file);
}

void separateNumbersToFiles(int *arr, int n) {
    FILE *evenFile = fopen("Even.txt", "w");  // Open Even.txt in write mode
    FILE *oddFile = fopen("Odd.txt", "w");    // Open Odd.txt in write mode
    if (evenFile == NULL || oddFile == NULL) {
        printf("Error opening files!\n");
        exit(1);
    }

    for (int i = 0; i < n; i++) {
        if (*(arr + i) % 2 == 0) {
            fprintf(evenFile, "%d\n", *(arr + i));  // Write even numbers to Even.txt
        } else {
            fprintf(oddFile, "%d\n", *(arr + i));   // Write odd numbers to Odd.txt
        }
    }

    fclose(evenFile);
    fclose(oddFile);
}

void displayFileContents(const char *fileName) {
    FILE *file = fopen(fileName, "r");
    if (file == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }

    int num;
    printf("Contents of %s:\n", fileName);
    while (fscanf(file, "%d", &num) != EOF) {
        printf("%d ", num);  // Print each number in the file
    }
    printf("\n");

    fclose(file);
}

int main() {
    int n;
    printf("Enter the number of integers: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);  // Read integers into the array
    }

    // Write the integers to All.txt
    writeToFile(arr, n);

    // Separate even and odd numbers into Even.txt and Odd.txt
    separateNumbersToFiles(arr, n);

    displayFileContents("All.txt");
    displayFileContents("Even.txt");
    displayFileContents("Odd.txt");

    return 0;
}
