// 15 Write a java program static block which will be executed before main ( ) method in a
//    Class.


class StaticBlockExample {

    // Static block
    static {
        System.out.println("Static block executed before main method.");
    }

    public static void main(String[] args) {
        System.out.println("Main method executed.");
    }
}
