// 27 Write a java program to implement Generic class Number_1 for both data type int and float in
//    java.


public class Number_1<T> {
    private T number;

    public Number_1(T number) {
        this.number = number;
    }

    public void display() {
        System.out.println("Number: " + number);
    }

    public T add(T other) {
        if (number instanceof Integer && other instanceof Integer) {
            Integer result = (Integer) number + (Integer) other;
            return (T) result;
        } else if (number instanceof Float && other instanceof Float) {
            Float result = (Float) number + (Float) other;
            return (T) result;
        } else {
            throw new IllegalArgumentException("Incompatible types for addition");
        }
    }

    public static void main(String[] args) {
        
        Number_1<Integer> intNum = new Number_1<>(5);
        intNum.display();
        System.out.println("Sum: " + intNum.add(3));  

        Number_1<Float> floatNum = new Number_1<>(5.5f);
        floatNum.display();
        System.out.println("Sum: " + floatNum.add(3.2f));  
    }
}
