// 17 Write a class “circle” with radius as data member and count the number of instancescreated
//    using default constructor only. [Constructor Chaining]


public class Circle {
    
    private double radius;

    private static int instanceCount = 0;

    public Circle() {
        this(1.0); 
        instanceCount++;
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public Circle(Circle anotherCircle) {
        this(anotherCircle.radius);
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public static int getInstanceCount() {
        return instanceCount;
    }

    public static void main(String[] args) {
        System.out.println("Initial instance count: " + Circle.getInstanceCount());

        Circle circle1 = new Circle();
        Circle circle2 = new Circle();

        System.out.println("Radius of Circle 1: " + circle1.getRadius());
        System.out.println("Radius of Circle 2: " + circle2.getRadius());

        System.out.println("Instances created using default constructor: " + Circle.getInstanceCount());

        Circle circle3 = new Circle(5.0);
        System.out.println("Radius of Circle 3: " + circle3.getRadius());

        Circle circle4 = new Circle(circle3);
        System.out.println("Radius of Circle 4: " + circle4.getRadius());

        System.out.println("Final instance count: " + Circle.getInstanceCount());
    }
}
