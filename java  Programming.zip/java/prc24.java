// 24 Write a java program to implement an interface called Exam with a method Pass (int mark) that
//    returns a boolean. Write another interface called Classify with a method Division (int average)
//    which returns a String. Write a class called Result which implements both Exam and Classify.
//    The Pass method should return true if the mark is greater than or equal to 50 else false. The
//    Division method must return “First” when the parameter average is 60 or more, “Second” when
//    average is 50 or more but below 60, “No division” when average is less than 50.




interface Exam {
    boolean Pass(int mark);  
}

interface Classify {
    String Division(int average);  
}

class Result implements Exam, Classify {
    
    @Override
    public boolean Pass(int mark) {
        return mark >= 50;  
    }

    @Override
    public String Division(int average) {
        if (average >= 60) {
            return "First";  
        } else if (average >= 50) {
            return "Second";  
        } else {
            return "No division";  
        }
    }
}

public class Main {
    public static void main(String[] args) {
       
        Result result = new Result();

        int mark = 55;
        int average = 62;

        if (result.Pass(mark)) {
            System.out.println("The student has passed with marks: " + mark);
        } else {
            System.out.println("The student has failed with marks: " + mark);
        }

        String division = result.Division(average);
        System.out.println("The division based on average " + average + " is: " + division);
    }
}
