// 13 Write a program in Java to demonstrate use of this keyword. Check whether this canaccess
//    the Static variables of the class or not. [Refer class student in Q12 to perform the task]


class Student {
    private int enrollmentNo;
    private String name;
    private String gender;
    private double marks;
    private static int count = 0;

    public Student(int enrollmentNo, String name, String gender, double marks) {
        this.enrollmentNo = enrollmentNo;
        this.name = name;
        this.gender = gender;
        this.marks = marks;
        count++;
    }

    public void display() {
        System.out.println("Enrollment No: " + this.enrollmentNo);
        System.out.println("Name: " + this.name);
        System.out.println("Gender: " + this.gender);
        System.out.println("Marks: " + this.marks);
        System.out.println();
    }

    public void displayCountUsingThis() {
        
        System.out.println("Static variables cannot be accessed using 'this'. Use the class name instead: Count = " + Student.count);
    }

    public static int getCount() {
        return count;
    }
}

public class StudentDemo {
    public static void main(String[] args) {
        
        Student student1 = new Student(101, "Alice", "Female", 90.0);
        Student student2 = new Student(102, "Bob", "Male", 85.5);

        System.out.println("Student Details:");
        student1.display();
        student2.display();

        System.out.println("Demonstrating 'this' keyword:");
        student1.displayCountUsingThis();
    }
}
