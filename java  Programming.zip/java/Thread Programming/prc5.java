// 5. Write java program that create and runs following threads:
//    a) print "A" 20 times
//    b) print "B" 30 times
//    c) print "C" 15 times


class PrintA extends Thread {
    public void run() {
        for (int i = 0; i < 20; i++) {
            System.out.println("A");
            try {
                Thread.sleep(500); 
            } catch (InterruptedException e) {
                System.out.println("Thread A interrupted.");
            }
        }
    }
}


class PrintB extends Thread {
    public void run() {
        for (int i = 0; i < 30; i++) {
            System.out.println("B");
            try {
                Thread.sleep(500); 
            } catch (InterruptedException e) {
                System.out.println("Thread B interrupted.");
            }
        }
    }
}


class PrintC extends Thread {
    public void run() {
        for (int i = 0; i < 15; i++) {
            System.out.println("C");
            try {
                Thread.sleep(500); 
            } catch (InterruptedException e) {
                System.out.println("Thread C interrupted.");
            }
        }
    }
}

public class MultipleThreads {
    public static void main(String[] args) {
        
        PrintA threadA = new PrintA();
        PrintB threadB = new PrintB();
        PrintC threadC = new PrintC();
        
        threadA.start();
        threadB.start();
        threadC.start();
        
        try {
            
            threadA.join();
            threadB.join();
            threadC.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }
    }
}
