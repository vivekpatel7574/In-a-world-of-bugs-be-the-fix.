// 6. Write a program in Java to demonstrate use of synchronization of threads when multiple threads
//    are trying to update common variable for “Account” class.


class Account {
    private int balance;

    
    public Account(int balance) {
        this.balance = balance;
    }

    
    public synchronized void deposit(int amount) {
        balance += amount;
        System.out.println("Deposited: " + amount + ", New Balance: " + balance);
    }

    
    public synchronized void withdraw(int amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: " + amount + ", New Balance: " + balance);
        } else {
            System.out.println("Insufficient funds for withdrawal of " + amount);
        }
    }

   
    public int getBalance() {
        return balance;
    }
}


class DepositThread extends Thread {
    private Account account;
    private int amount;

    public DepositThread(Account account, int amount) {
        this.account = account;
        this.amount = amount;
    }

    @Override
    public void run() {
        account.deposit(amount);
    }
}


class WithdrawalThread extends Thread {
    private Account account;
    private int amount;

    public WithdrawalThread(Account account, int amount) {
        this.account = account;
        this.amount = amount;
    }

    @Override
    public void run() {
        account.withdraw(amount);
    }
}

public class SynchronizationDemo {
    public static void main(String[] args) {
        
        Account account = new Account(1000);

        
        DepositThread depositThread1 = new DepositThread(account, 500);
        DepositThread depositThread2 = new DepositThread(account, 300);

        WithdrawalThread withdrawThread1 = new WithdrawalThread(account, 200);
        WithdrawalThread withdrawThread2 = new WithdrawalThread(account, 400);

        depositThread1.start();
        depositThread2.start();
        withdrawThread1.start();
        withdrawThread2.start();

        try {
            
            depositThread1.join();
            depositThread2.join();
            withdrawThread1.join();
            withdrawThread2.join();
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted.");
        }

        System.out.println("Final Balance: " + account.getBalance());
    }
}
