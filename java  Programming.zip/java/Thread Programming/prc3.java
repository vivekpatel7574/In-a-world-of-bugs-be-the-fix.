// 3. Write a program that executes two threads. One thread displays “Thread1” every 2,000
//    milliseconds, and the other displays “Thread2” every 4,000 milliseconds.


class Thread1 extends Thread {
    public void run() {
        try {
            while (true) {
                System.out.println("Thread1");
                Thread.sleep(2000); 
            }
        } catch (InterruptedException e) {
            System.out.println("Thread1 interrupted.");
        }
    }
}


class Thread2 extends Thread {
    public void run() {
        try {
            while (true) {
                System.out.println("Thread2");
                Thread.sleep(4000); 
            }
        } catch (InterruptedException e) {
            System.out.println("Thread2 interrupted.");
        }
    }
}

public class TwoThreadsExample {
    public static void main(String[] args) {
       
        Thread1 t1 = new Thread1();
        Thread2 t2 = new Thread2();
        
        
        t1.start();
        t2.start();
        
        try {
            
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }
    }
}
