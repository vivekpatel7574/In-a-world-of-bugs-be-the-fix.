// 4. Write a program that executes two threads. One thread will print the even numbers and another
//    thread will print odd numbers from 1 to 50.


class EvenNumbers extends Thread {
    public void run() {
        for (int i = 2; i <= 50; i += 2) {
            System.out.println("Even: " + i);
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                System.out.println("Even thread interrupted.");
            }
        }
    }
}


class OddNumbers extends Thread {
    public void run() {
        for (int i = 1; i <= 50; i += 2) {
            System.out.println("Odd: " + i);
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                System.out.println("Odd thread interrupted.");
            }
        }
    }
}

public class EvenOddThreads {
    public static void main(String[] args) {
        
        EvenNumbers evenThread = new EvenNumbers();
        OddNumbers oddThread = new OddNumbers();
        
       
        evenThread.start();
        oddThread.start();
        
        try {
            
            evenThread.join();
            oddThread.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }
    }
}
