// 1 Write a program to implement the concept of threading by extending “Thread” Class.


class MyThread extends Thread {
    
    
    public void run() {
       
        System.out.println("Thread " + Thread.currentThread().getId() + " is running.");
        
        try {
            
            for (int i = 1; i <= 5; i++) {
                System.out.println("Thread " + Thread.currentThread().getId() + " is working: " + i);
                Thread.sleep(500);  
            }
        } catch (InterruptedException e) {
            System.out.println("Thread " + Thread.currentThread().getId() + " was interrupted.");
        }
        
        System.out.println("Thread " + Thread.currentThread().getId() + " has completed.");
    }
}

public class ThreadExample {
    public static void main(String[] args) {
        
        MyThread thread1 = new MyThread();
        MyThread thread2 = new MyThread();
        
        thread1.start();
        thread2.start();
        
        try {
            
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }

        System.out.println("Main thread has finished.");
    }
}
