// 2 Write a program to implement the concept of threading by implementing “Runnable”
//   Interface.


class MyRunnable implements Runnable {
    
   
    public void run() {
        
        System.out.println("Thread " + Thread.currentThread().getId() + " is running.");
        
        try {
            
            for (int i = 1; i <= 5; i++) {
                System.out.println("Thread " + Thread.currentThread().getId() + " is working: " + i);
                Thread.sleep(500);  
            }
        } catch (InterruptedException e) {
            System.out.println("Thread " + Thread.currentThread().getId() + " was interrupted.");
        }
        
        System.out.println("Thread " + Thread.currentThread().getId() + " has completed.");
    }
}

public class RunnableExample {
    public static void main(String[] args) {
        
        MyRunnable myRunnable1 = new MyRunnable();
        MyRunnable myRunnable2 = new MyRunnable();
        
        
        Thread thread1 = new Thread(myRunnable1);
        Thread thread2 = new Thread(myRunnable2);
        
       
        thread1.start();
        thread2.start();
        
        try {
           
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted.");
        }

        System.out.println("Main thread has finished.");
    }
}
