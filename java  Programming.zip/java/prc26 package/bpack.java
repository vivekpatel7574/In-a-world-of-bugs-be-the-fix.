// bpack/B.java
package bpack;
import apack.A;

public class B extends A {
    
    public B() {
        System.out.println("Class B Constructor");
    }

    public void display() {
        
        System.out.println("Public Variable from A: " + publicVar);
        
        System.out.println("Protected Variable from A: " + protectedVar);


    }
}
