// dpack/ProtectedDemo.java
package dpack;
import bpack.B;
import cpack.C;

public class ProtectedDemo {
    
    public static void main(String[] args) {
        
        B b = new B();
        b.display();

        C c = new C();
        c.display();
    }
}
