// cpack/C.java
package cpack;
import apack.A;

public class C {
    
    public void display() {
        A a = new A();
        
        System.out.println("Public Variable from A: " + a.publicVar);
        

    }
}
