// 18 Create a class “Vehicle” with instance variable vehicle_type. Inherit the class in a class called
//    “Car” with instance model_type, company name etc. display the information of the vehicle
//    by defining the display() in both super and sub class [Method Overriding]



class Vehicle {
    
    String vehicle_type;

    public Vehicle(String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }

    public void display() {
        System.out.println("Vehicle Type: " + vehicle_type);
    }
}

class Car extends Vehicle {
    
    String model_type;
    String company_name;

    public Car(String vehicle_type, String model_type, String company_name) {
        super(vehicle_type);  
        this.model_type = model_type;
        this.company_name = company_name;
    }

    @Override
    public void display() {
        
        super.display(); 
        
        System.out.println("Model Type: " + model_type);
        System.out.println("Company Name: " + company_name);
    }
}

public class Main {
    public static void main(String[] args) {
        
        Car car = new Car("Sedan", "Model S", "Tesla");
        
        car.display();
    }
}
