// 14 Create a class “Rectangle” that would contain length and width as an instance variable and
//    count as a static variable.
//    Define constructors [constructor overloading (default, parameterized and copy)] to
//    initialize variables of objects. Define methods to find area and to display variables’value of
//    objects which are created.
//    [Note: define initializer block, static initializer block and the static variable and method. Also
//    demonstrate the sequence of execution of initializer block and static initialize block]



class Rectangle {
    private double length;
    private double width;
    private static int count;

    static {
        count = 0;
        System.out.println("Static initializer block executed. Initial count = " + count);
    }

    {
        System.out.println("Instance initializer block executed.");
    }

    public Rectangle() {
        this(1.0, 1.0); 
        System.out.println("Default constructor executed.");
    }

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
        count++;
        System.out.println("Parameterized constructor executed.");
    }

    public Rectangle(Rectangle rectangle) {
        this(rectangle.length, rectangle.width); 
        System.out.println("Copy constructor executed.");
    }

    public double getArea() {
        return length * width;
    }

    public void display() {
        System.out.println("Length: " + length);
        System.out.println("Width: " + width);
        System.out.println("Area: " + getArea());
    }

    public static int getCount() {
        return count;
    }
}

public class RectangleDemo {
    public static void main(String[] args) {
        System.out.println("Creating first rectangle:");
        Rectangle rect1 = new Rectangle();
        rect1.display();

        System.out.println("\nCreating second rectangle with parameters:");
        Rectangle rect2 = new Rectangle(5.0, 3.0);
        rect2.display();

        System.out.println("\nCreating third rectangle using copy constructor:");
        Rectangle rect3 = new Rectangle(rect2);
        rect3.display();

        System.out.println("\nTotal number of rectangles created: " + Rectangle.getCount());
    }
}
