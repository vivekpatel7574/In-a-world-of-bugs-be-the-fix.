// 9 Write a java program to create a class “Matrix” that would contain integer values havingvaried
//    Numbers of columns for each row. Print row-wise sum of the integer values for eachrow.


import java.util.Scanner;

class Matrix {
    private int[][] data;
    private int rows;

    public Matrix(int rows) {
        this.rows = rows;
        this.data = new int[rows][];
    }

    public void inputMatrix(Scanner scanner) {
        for (int i = 0; i < rows; i++) {
            System.out.print("Enter the number of columns for row " + (i + 1) + ": ");
            int cols = scanner.nextInt();
            data[i] = new int[cols];
            System.out.println("Enter elements for row " + (i + 1) + ":");
            for (int j = 0; j < cols; j++) {
                data[i][j] = scanner.nextInt();
            }
        }
    }

    public void printRowWiseSum() {
        for (int i = 0; i < rows; i++) {
            int sum = 0;
            for (int val : data[i]) {
                sum += val;
            }
            System.out.println("Sum of row " + (i + 1) + ": " + sum);
        }
    }
}

public class MatrixRowSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of rows in the matrix: ");
        int rows = scanner.nextInt();

        Matrix matrix = new Matrix(rows);

        matrix.inputMatrix(scanner);

        System.out.println("Row-wise sums:");
        matrix.printRowWiseSum();

        scanner.close();
    }
}
