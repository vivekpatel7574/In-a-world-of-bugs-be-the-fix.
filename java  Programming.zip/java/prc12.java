// 12 Create a class “Student” that would contain enrollment No, name, and gender andmarks as
//    instance variables and count as static variable which stores the count of the objects;
//    constructors and display(). Implement constructors to initialize instance variables. Also
//    demonstrate constructor chaining. Create objects of class “Student” and displays all values of
//    objects.


class Student {
    private int enrollmentNo;
    private String name;
    private String gender;
    private double marks;
    private static int count = 0;

    public Student() {
        this(0, "Unknown", "Unknown", 0.0);
    }

    public Student(int enrollmentNo, String name) {
        this(enrollmentNo, name, "Unknown", 0.0);
    }

    public Student(int enrollmentNo, String name, String gender, double marks) {
        this.enrollmentNo = enrollmentNo;
        this.name = name;
        this.gender = gender;
        this.marks = marks;
        count++;
    }

    public void display() {
        System.out.println("Enrollment No: " + enrollmentNo);
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Marks: " + marks);
        System.out.println();
    }

    public static int getCount() {
        return count;
    }
}

public class StudentDemo {
    public static void main(String[] args) {
        
        Student student1 = new Student();
        Student student2 = new Student(101, "Alice");
        Student student3 = new Student(102, "Bob", "Male", 85.5);

        System.out.println("Student Details:");
        student1.display();
        student2.display();
        student3.display();

        System.out.println("Total number of students: " + Student.getCount());
    }
}
