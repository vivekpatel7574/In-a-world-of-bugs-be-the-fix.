// 7 Write a java program which should display maximum number of given 4 numbers.


import java.util.Scanner;

public class MaximumOfFour {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        int num1 = scanner.nextInt();

        System.out.print("Enter the second number: ");
        int num2 = scanner.nextInt();

        System.out.print("Enter the third number: ");
        int num3 = scanner.nextInt();

        System.out.print("Enter the fourth number: ");
        int num4 = scanner.nextInt();

        int max = (num1 > num2) 
                    ? (num1 > num3 
                        ? (num1 > num4 ? num1 : num4) 
                        : (num3 > num4 ? num3 : num4))
                    : (num2 > num3 
                        ? (num2 > num4 ? num2 : num4) 
                        : (num3 > num4 ? num3 : num4));

        System.out.println("The maximum of the four numbers is: " + max);
    }
}
