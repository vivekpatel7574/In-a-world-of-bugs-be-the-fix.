// 4 Write a java program to print value ofx^n. Input: x=5 Input: n=3 Output: 125


import java.util.Scanner;

public class PowerCalculation {

    public static long power(int x, int n) {
        long result = 1;
        for (int i = 1; i <= n; i++) {
            result *= x;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the base (x): ");
        int x = scanner.nextInt();

        System.out.print("Enter the exponent (n): ");
        int n = scanner.nextInt();

        long result = power(x, n);
        System.out.println("The value of " + x + "^" + n + " is: " + result);
    }
}