// 39 Write a java program to create a file to the specified location.


import java.io.File;
import java.io.IOException;

public class CreateFileExample {

    public static void main(String[] args) {
       
        File file = new File("C:\\Users\\YourUsername\\Documents\\example.txt");  

        try {
            
            if (file.createNewFile()) {
                System.out.println("File created successfully: " + file.getName());
            } else {
                System.out.println("File already exists: " + file.getName());
            }
        } catch (IOException e) {
            
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
