// 10 Write a Java application which takes several command line arguments, which aresupposed
//    to be names of students and prints output as given below:
//    (Suppose we enter 3 names then output should be asfollows).. Number of arguments = 3
//    1.First Student Name is = Arun
//    2.Second Student Name is = Hiren
//    3.Third Student Name is = Hitesh


public class CommandLineStudents {
    public static void main(String[] args) {
        
        if (args.length == 0) {
            System.out.println("No student names were provided.");
            return;
        }

        System.out.println("Number of arguments = " + args.length);

        for (int i = 0; i < args.length; i++) {
            String ordinal;
            switch (i + 1) {
                case 1:
                    ordinal = "First";
                    break;
                case 2:
                    ordinal = "Second";
                    break;
                case 3:
                    ordinal = "Third";
                    break;
                default:
                    ordinal = (i + 1) + "th";
                    break;
            }
            System.out.println(ordinal + " Student Name is = " + args[i]);
        }
    }
}
