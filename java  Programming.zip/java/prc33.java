// 33 Write a small application in Java to develop Banking Application in which user deposits the
//    amount Rs 1000.00 and then start withdrawing of Rs 400.00, Rs 300.00 and it throws exception
//    "Not Sufficient Fund" when user withdraws Rs. 500 thereafter.



class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        balance = initialBalance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited Rs. " + amount + ". Current balance: Rs. " + balance);
    }

    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException("Not Sufficient Funds! Current balance: Rs. " + balance);
        }
        balance -= amount;
        System.out.println("Withdrawn Rs. " + amount + ". Current balance: Rs. " + balance);
    }

    public double getBalance() {
        return balance;
    }
}

public class BankingApplication {

    public static void main(String[] args) {
        
        BankAccount account = new BankAccount(1000.00);

        account.deposit(1000.00);

        try {
            account.withdraw(400.00);
            account.withdraw(300.00); 

            account.withdraw(500.00);
        } catch (InsufficientFundsException e) {
            System.out.println(e.getMessage());
        }
    }
}
