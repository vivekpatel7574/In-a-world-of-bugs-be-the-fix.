// 35 Write a program for Java Generics class for Sorting operations:
//    1. Sorting a list according to natural ordering of elements
//    2. Reversing sort order
//    3. Sorting a list whose elements of a custom type
//    4. Sorting a list using a Comparator. [desirable]


import java.util.*;

class Student {
    String name;
    int age;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Student{name='" + name + "', age=" + age + "}";
    }
}

public class SortingOperations<T> {

    public void sortListNaturally(List<T> list) {
        Collections.sort(list);
        System.out.println("Sorted list (Natural Order): " + list);
    }

    public void sortListInReverseOrder(List<T> list) {
        Collections.sort(list, Collections.reverseOrder());
        System.out.println("Sorted list (Reverse Order): " + list);
    }

    public void sortCustomTypeList(List<Student> list) {
        Collections.sort(list, new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                return s1.getAge() - s2.getAge(); 
            }
        });
        System.out.println("Sorted list (Custom Type - Age Order): " + list);
    }

    public void sortListUsingComparator(List<T> list, Comparator<T> comparator) {
        Collections.sort(list, comparator);
        System.out.println("Sorted list (Using Comparator): " + list);
    }

    public static void main(String[] args) {

        SortingOperations<Integer> integerSorter = new SortingOperations<>();
        List<Integer> integers = new ArrayList<>(Arrays.asList(3, 1, 4, 5, 2));
        
        integerSorter.sortListNaturally(integers);
        
        integerSorter.sortListInReverseOrder(integers);

        SortingOperations<Student> studentSorter = new SortingOperations<>();
        List<Student> students = new ArrayList<>();
        students.add(new Student("John", 20));
        students.add(new Student("Alice", 22));
        students.add(new Student("Bob", 19));

        studentSorter.sortCustomTypeList(students);

        studentSorter.sortListUsingComparator(students, new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                return s1.getName().compareTo(s2.getName()); 
            }
        });
    }
}
