// 21 Write a program in Java to demonstrate the use of 'final' keyword in the fielddeclaration.
//    How it is accessed using the objects.


class Car {
    
    final String make;
    final int year;

    public Car(String make, int year) {
        this.make = make;
        this.year = year;
    }

    public void displayCarDetails() {
        System.out.println("Car Make: " + make);
        System.out.println("Car Year: " + year);
    }
}

public class Main {
    public static void main(String[] args) {
        
        Car myCar = new Car("Tesla", 2024);

        myCar.displayCarDetails();

      
    }
}
