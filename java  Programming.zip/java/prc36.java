// 36 Write a program in Java to create, write, modify, read operations on a Text file.


import java.io.*;

public class FileOperations {

    
    public void createAndWriteFile(String filename) {
        try {
            
            FileWriter writer = new FileWriter(filename);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            bufferedWriter.write("Hello, this is the first line.");
            bufferedWriter.newLine();
            bufferedWriter.write("This is the second line.");
            bufferedWriter.newLine();

            bufferedWriter.close();
            System.out.println("File created and written successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    }

    public void modifyFile(String filename) {
        try {
           
            FileWriter writer = new FileWriter(filename, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            bufferedWriter.newLine();
            bufferedWriter.write("This is a new line added to the file.");

            bufferedWriter.close();
            System.out.println("File modified successfully.");
        } catch (IOException e) {
            System.out.println("Error modifying the file: " + e.getMessage());
        }
    }

    public void readFile(String filename) {
        try {
            
            FileReader reader = new FileReader(filename);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;
            System.out.println("Reading the content of the file:");
            
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

            bufferedReader.close();
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        FileOperations fileOps = new FileOperations();
        String filename = "example.txt";

        fileOps.createAndWriteFile(filename);

        fileOps.modifyFile(filename);

        fileOps.readFile(filename);
    }
}
