// 16 Write programs in Java to use Wrapper class of each primitive data types.


public class WrapperClassExample {
    
    public static void main(String[] args) {

        // Integer Wrapper Class
        Integer intWrapper = Integer.valueOf(42);
        int intPrimitive = intWrapper.intValue();
        System.out.println("Integer Wrapper: " + intWrapper);
        System.out.println("Converted to Primitive: " + intPrimitive);

        // Double Wrapper Class
        Double doubleWrapper = Double.valueOf(3.14159);
        double doublePrimitive = doubleWrapper.doubleValue();
        System.out.println("Double Wrapper: " + doubleWrapper);
        System.out.println("Converted to Primitive: " + doublePrimitive);

        // Character Wrapper Class
        Character charWrapper = Character.valueOf('A');
        char charPrimitive = charWrapper.charValue();
        System.out.println("Character Wrapper: " + charWrapper);
        System.out.println("Converted to Primitive: " + charPrimitive);

        // Boolean Wrapper Class
        Boolean booleanWrapper = Boolean.valueOf(true);
        boolean booleanPrimitive = booleanWrapper.booleanValue();
        System.out.println("Boolean Wrapper: " + booleanWrapper);
        System.out.println("Converted to Primitive: " + booleanPrimitive);

        // Byte Wrapper Class
        Byte byteWrapper = Byte.valueOf((byte) 10);
        byte bytePrimitive = byteWrapper.byteValue();
        System.out.println("Byte Wrapper: " + byteWrapper);
        System.out.println("Converted to Primitive: " + bytePrimitive);

        // Short Wrapper Class
        Short shortWrapper = Short.valueOf((short) 20);
        short shortPrimitive = shortWrapper.shortValue();
        System.out.println("Short Wrapper: " + shortWrapper);
        System.out.println("Converted to Primitive: " + shortPrimitive);

        // Long Wrapper Class
        Long longWrapper = Long.valueOf(123456789L);
        long longPrimitive = longWrapper.longValue();
        System.out.println("Long Wrapper: " + longWrapper);
        System.out.println("Converted to Primitive: " + longPrimitive);

        // Float Wrapper Class
        Float floatWrapper = Float.valueOf(2.71828f);
        float floatPrimitive = floatWrapper.floatValue();
        System.out.println("Float Wrapper: " + floatWrapper);
        System.out.println("Converted to Primitive: " + floatPrimitive);
    }
}
