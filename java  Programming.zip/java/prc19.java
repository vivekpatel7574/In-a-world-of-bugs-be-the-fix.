// 19 Create a class “Account” containing accountNo, and balance as an instance variable. Derive
//    the Account class into two classes named “Savings” and “Current”. The“Savings” class
//    should contain instance variable named interestRate, and the “Current”class should contain
//    instance variable called overdraftLimit. Define appropriatemethods for all the classes to
//    enable functionalities to check balance, deposit, andwithdraw amount in Savings and Current
//    account. [Ensure that the Account class cannot be instantiated.]



abstract class Account {
    
    String accountNo;
    double balance;

    public Account(String accountNo, double balance) {
        this.accountNo = accountNo;
        this.balance = balance;
    }

    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);
    
    public void checkBalance() {
        System.out.println("Current balance: " + balance);
    }
}

class Savings extends Account {
    
    double interestRate;

    public Savings(String accountNo, double balance, double interestRate) {
        super(accountNo, balance);
        this.interestRate = interestRate;
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited " + amount + " into Savings account.");
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew " + amount + " from Savings account.");
        } else {
            System.out.println("Insufficient balance or invalid withdrawal amount.");
        }
    }
}

class Current extends Account {
    
    double overdraftLimit;

    public Current(String accountNo, double balance, double overdraftLimit) {
        super(accountNo, balance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited " + amount + " into Current account.");
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 0 && (balance + overdraftLimit) >= amount) {
            balance -= amount;
            System.out.println("Withdrew " + amount + " from Current account.");
        } else {
            System.out.println("Insufficient balance or overdraft limit exceeded.");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        
        Savings savingsAccount = new Savings("SA123", 1000.0, 4.5);
        savingsAccount.checkBalance();
        savingsAccount.deposit(500);
        savingsAccount.withdraw(200);
        savingsAccount.checkBalance();

        Current currentAccount = new Current("CA123", 1000.0, 500.0);
        currentAccount.checkBalance();
        currentAccount.deposit(300);
        currentAccount.withdraw(1200);
        currentAccount.checkBalance();
    }
}
