// 43 Write a generic method to count the number of elements in a collection that have a specific
//    property (for example, odd integers, prime numbers, palindromes).


import java.util.*;

public class GenericPropertyCounter {

    public static void main(String[] args) {
        
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        System.out.println("Count of odd numbers: " + countMatchingElements(numbers, GenericPropertyCounter::isOdd));

        List<Integer> primes = Arrays.asList(2, 3, 4, 5, 6, 7, 8, 9, 10, 11);
        System.out.println("Count of prime numbers: " + countMatchingElements(primes, GenericPropertyCounter::isPrime));

        List<String> words = Arrays.asList("radar", "hello", "level", "world", "madam");
        System.out.println("Count of palindromes: " + countMatchingElements(words, GenericPropertyCounter::isPalindrome));
    }

    public static <T> int countMatchingElements(Collection<T> collection, PropertyChecker<T> checker) {
        int count = 0;
        for (T element : collection) {
            if (checker.check(element)) {
                count++;
            }
        }
        return count;
    }

    @FunctionalInterface
    public interface PropertyChecker<T> {
        boolean check(T element);
    }

    public static boolean isOdd(int number) {
        return number % 2 != 0;
    }

    public static boolean isPrime(int number) {
        if (number <= 1) return false;
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) return false;
        }
        return true;
    }

    public static boolean isPalindrome(String str) {
        String reversed = new StringBuilder(str).reverse().toString();
        return str.equals(reversed);
    }
}
