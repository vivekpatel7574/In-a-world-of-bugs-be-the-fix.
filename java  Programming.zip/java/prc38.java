// 38 Write a java program to checks the existence of a specified file.


import java.io.File;

public class FileExistenceCheck {

    public static void main(String[] args) {
       
        File file = new File("example.txt");  

        if (file.exists()) {
            System.out.println("The file " + file.getName() + " exists.");
        } else {
            System.out.println("The file " + file.getName() + " does not exist.");
        }
    }
}
