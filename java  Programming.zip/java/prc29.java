// 29 Write a java program to use important methods of String class.


import java.util.Scanner;

public class StringMethodsDemo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String str = scanner.nextLine();


        System.out.println("Length of the string: " + str.length());

        System.out.print("Character at index 2: ");
        if (str.length() > 2) {
            System.out.println(str.charAt(2));
        } else {
            System.out.println("Index out of bounds");
        }

        System.out.println("Substring from index 3: " + str.substring(3));

        System.out.println("Substring from index 3 to 6: " + str.substring(3, 6));

        System.out.println("String in lowercase: " + str.toLowerCase());

        System.out.println("String in uppercase: " + str.toUpperCase());

        System.out.println("String after trimming: '" + str.trim() + "'");

        System.out.println("String after replacing 'a' with 'o': " + str.replace('a', 'o'));

        System.out.print("Index of 'example' in the string: ");
        int index = str.indexOf("example");
        if (index != -1) {
            System.out.println(index);
        } else {
            System.out.println("'example' not found");
        }

        System.out.print("Enter another string to compare with the original: ");
        String anotherString = scanner.nextLine();
        if (str.equals(anotherString)) {
            System.out.println("The strings are equal.");
        } else {
            System.out.println("The strings are not equal.");
        }

        scanner.close();
    }
}
