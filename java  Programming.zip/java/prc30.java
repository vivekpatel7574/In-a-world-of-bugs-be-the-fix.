// 30 Write a program in Java to demonstrate use of final class, final variable and final method



final class FinalClass {
    
    final int CONSTANT = 100;

    public final void displayMessage() {
        System.out.println("This is a final method.");
    }
}



public class FinalKeywordDemo {

    public static void main(String[] args) {
        
        FinalClass finalObj = new FinalClass();

        finalObj.displayMessage();

        System.out.println("The value of CONSTANT is: " + finalObj.CONSTANT);
        
    }
}
