// 11 Write a Java application to count and display frequency of letters and digits from theString
//    given by user as command-line argument.


public class LetterDigitFrequency {
    public static void main(String[] args) {
        
        if (args.length == 0) {
            System.out.println("No input string provided. Please provide a string as a command-line argument.");
            return;
        }

        String input = String.join(" ", args);

        int letterCount = 0;
        int digitCount = 0;

        for (char ch : input.toCharArray()) {
            if (Character.isLetter(ch)) {
                letterCount++;
            } else if (Character.isDigit(ch)) {
                digitCount++;
            }
        }

        System.out.println("Input String: " + input);
        System.out.println("Number of letters: " + letterCount);
        System.out.println("Number of digits: " + digitCount);
    }
}
