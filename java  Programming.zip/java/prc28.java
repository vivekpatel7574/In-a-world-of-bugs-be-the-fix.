// 28 Write a java program to accept string to check whether it is in Upper or Lower case. After
//    checking, case will be reversed.


import java.util.Scanner;

public class ReverseCase {
    
    public static String reverseCase(String str) {
        StringBuilder reversedString = new StringBuilder();
        
       
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            
            
            if (Character.isLowerCase(c)) {
                reversedString.append(Character.toUpperCase(c));
            } 
            
            else if (Character.isUpperCase(c)) {
                reversedString.append(Character.toLowerCase(c));
            } else {
                
                reversedString.append(c);
            }
        }
        
        return reversedString.toString();
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter a string: ");
        String inputString = scanner.nextLine();
        
        if (inputString.equals(inputString.toUpperCase())) {
            System.out.println("The string is in Uppercase.");
        } else if (inputString.equals(inputString.toLowerCase())) {
            System.out.println("The string is in Lowercase.");
        } else {
            System.out.println("The string contains both Uppercase and Lowercase letters.");
        }
        
        String resultString = reverseCase(inputString);
        
        System.out.println("String after reversing case: " + resultString);
        
        scanner.close();
    }
}
