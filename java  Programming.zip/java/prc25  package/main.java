// Main.java
import student.Student;
import exam.Result;

public class Main {
    public static void main(String[] args) {
        
        int[] marks = {85, 75, 90, 88, 92}; 
        Student student = new Student("John Doe", 101, marks);

        Result result = new Result();
        result.displayMarkSheet(student);
    }
}
