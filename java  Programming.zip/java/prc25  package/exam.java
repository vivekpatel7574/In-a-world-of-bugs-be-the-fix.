// exam/Result.java
package exam;

import student.Student;

public class Result {

    public int calculateTotalMarks(Student student) {
        int total = 0;
        for (int mark : student.getMarks()) {
            total += mark;
        }
        return total;
    }

    public double calculatePercentage(Student student) {
        int totalMarks = calculateTotalMarks(student);
        return (totalMarks / (double) (student.getMarks().length * 100)) * 100;
    }

    public String generateResult(Student student) {
        double percentage = calculatePercentage(student);
        String result = (percentage >= 50) ? "Pass" : "Fail";
        return result;
    }

    public void displayMarkSheet(Student student) {
        System.out.println("Mark Sheet for " + student.getName());
        System.out.println("Roll No: " + student.getRollNo());
        System.out.println("Marks Obtained: ");
        
        int[] marks = student.getMarks();
        for (int i = 0; i < marks.length; i++) {
            System.out.println("Subject " + (i+1) + ": " + marks[i]);
        }

        int totalMarks = calculateTotalMarks(student);
        double percentage = calculatePercentage(student);
        String result = generateResult(student);

        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Percentage: " + percentage + "%");
        System.out.println("Result: " + result);
    }
}
