// 32 Write a program in Java to demonstrate throw, throws, finally, multiple try block and multiple
//    catch exception.



class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionDemo {

    public static void methodWithThrows() throws CustomException {
        System.out.println("Inside methodWithThrows()");
        throw new CustomException("This is a custom exception thrown from methodWithThrows()");
    }

    public static void methodWithThrow(int value) {
        if (value == 0) {
            throw new ArithmeticException("Cannot divide by zero!");
        }
        System.out.println("Value is: " + value);
    }

    public static void main(String[] args) {
        
        try {
            System.out.println("First try block:");
            methodWithThrows();  
        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught general exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block for first try block executed!");
        }

        try {
            System.out.println("\nSecond try block:");
            methodWithThrow(0);  
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught general exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block for second try block executed!");
        }

       
        try {
            System.out.println("\nThird try block (no exception):");
            methodWithThrow(10); 
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.getMessage());
        } finally {
            System.out.println("Finally block for third try block executed!");
        }
    }
}
