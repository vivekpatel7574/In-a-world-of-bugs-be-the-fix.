// 44 Write a generic method to exchange the positions of two different elements in an array.


public class GenericArrayExchange {

    public static void main(String[] args) {
        
        Integer[] intArray = {1, 2, 3, 4, 5};
        System.out.println("Before exchange: ");
        printArray(intArray);
        exchange(intArray, 1, 3);  
        System.out.println("After exchange: ");
        printArray(intArray);

        String[] strArray = {"apple", "banana", "cherry", "date"};
        System.out.println("\nBefore exchange: ");
        printArray(strArray);
        exchange(strArray, 0, 2);  
        System.out.println("After exchange: ");
        printArray(strArray);
    }

    public static <T> void exchange(T[] array, int index1, int index2) {
        if (index1 >= 0 && index1 < array.length && index2 >= 0 && index2 < array.length) {
            T temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        } else {
            System.out.println("Invalid indices!");
        }
    }

    public static <T> void printArray(T[] array) {
        for (T element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}
