
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

public class CircleFileOperations {

    public static void addCircleToFile(Circle circle, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename, true))) {
            oos.writeObject(circle);
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    public static ArrayList<Circle> getCirclesFromFile(String filename) {
        ArrayList<Circle> circles = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            while (true) {
                try {
                    Circle circle = (Circle) ois.readObject();
                    circles.add(circle);
                } catch (EOFException e) {
                    break; 
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
        return circles;
    }

    public static void updateCircleInFile(Circle oldCircle, Circle newCircle, String filename) {
        ArrayList<Circle> circles = getCirclesFromFile(filename);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            for (Circle circle : circles) {
                if (circle.equals(oldCircle)) {
                    oos.writeObject(newCircle);
                } else {
                    oos.writeObject(circle);
                }
            }
        } catch (IOException e) {
            System.out.println("Error updating file: " + e.getMessage());
        }
    }

    public static void removeCircleFromFile(Circle circleToRemove, String filename) {
        ArrayList<Circle> circles = getCirclesFromFile(filename);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            for (Circle circle : circles) {
                if (!circle.equals(circleToRemove)) {
                    oos.writeObject(circle);
                }
            }
        } catch (IOException e) {
            System.out.println("Error removing from file: " + e.getMessage());
        }
    }

    public static void displayCircles(String filename) {
        ArrayList<Circle> circles = getCirclesFromFile(filename);
        Iterator<Circle> iterator = circles.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }

    public static void main(String[] args) {
        String filename = "circles.dat";

        Circle circle1 = new Circle(5, "Red");
        Circle circle2 = new Circle(7, "Blue");
        Circle circle3 = new Circle(10, "Green");
        Circle circle4 = new Circle(12, "Yellow");
        Circle circle5 = new Circle(4, "Pink");
        Circle circle6 = new Circle(6, "Purple");
        Circle circle7 = new Circle(8, "Orange");
        Circle circle8 = new Circle(9, "Brown");
        Circle circle9 = new Circle(11, "Black");
        Circle circle10 = new Circle(3, "White");

        addCircleToFile(circle1, filename);
        addCircleToFile(circle2, filename);
        addCircleToFile(circle3, filename);
        addCircleToFile(circle4, filename);
        addCircleToFile(circle5, filename);
        addCircleToFile(circle6, filename);
        addCircleToFile(circle7, filename);
        addCircleToFile(circle8, filename);
        addCircleToFile(circle9, filename);
        addCircleToFile(circle10, filename);

        System.out.println("Circles in the file:");
        displayCircles(filename);

        Circle updatedCircle = new Circle(15, "Red");
        updateCircleInFile(circle1, updatedCircle, filename);

        System.out.println("\nCircles after update:");
        displayCircles(filename);

        removeCircleFromFile(circle3, filename);

        System.out.println("\nCircles after removal:");
        displayCircles(filename);
    }
}
