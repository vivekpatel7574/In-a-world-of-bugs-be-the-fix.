// 34 Write a program to write at least 10 objects of the Circle class in a File and to perform basic
//    operations: adding, retrieving, updating, removing elements.


import java.io.Serializable;

public class Circle implements Serializable {
    private double radius;
    private String color;

    public Circle(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double area() {
        return Math.PI * radius * radius;
    }

    public String toString() {
        return "Circle [Radius: " + radius + ", Color: " + color + ", Area: " + area() + "]";
    }
}
