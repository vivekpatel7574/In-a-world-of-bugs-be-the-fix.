// 3. Develop a program to create Hash Map for “Customer” class objects references. Customer class
//    has Bill_no, cust_mobile_no, Array of item_name, Array of item_unit_price, Array of
//    item_count, total_price. Calculate total_price for all customers of Hash Map. Display Hash
//    Map and also search particular



import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Customer {
    int bill_no;
    String cust_mobile_no;
    String[] item_name;
    double[] item_unit_price;
    int[] item_count;
    double total_price;

    public Customer(int bill_no, String cust_mobile_no, String[] item_name, double[] item_unit_price, int[] item_count) {
        this.bill_no = bill_no;
        this.cust_mobile_no = cust_mobile_no;
        this.item_name = item_name;
        this.item_unit_price = item_unit_price;
        this.item_count = item_count;
        this.total_price = calculateTotalPrice();
    }

    private double calculateTotalPrice() {
        double total = 0;
        for (int i = 0; i < item_name.length; i++) {
            total += item_unit_price[i] * item_count[i];
        }
        return total;
    }

    public void displayCustomer() {
        System.out.println("Bill No: " + bill_no);
        System.out.println("Customer Mobile No: " + cust_mobile_no);
        System.out.println("Items Purchased:");
        for (int i = 0; i < item_name.length; i++) {
            System.out.println("Item: " + item_name[i] + ", Unit Price: " + item_unit_price[i] + ", Quantity: " + item_count[i]);
        }
        System.out.println("Total Price: " + total_price);
        System.out.println();
    }

    public int getBillNo() {
        return bill_no;
    }
}

public class CustomerHashMap {
    public static void main(String[] args) {
        
        HashMap<Integer, Customer> customerMap = new HashMap<>();
        Scanner sc = new Scanner(System.in);

        String[] items1 = {"Item1", "Item2"};
        double[] prices1 = {100, 200};
        int[] counts1 = {2, 3};
        customerMap.put(101, new Customer(101, "9876543210", items1, prices1, counts1));

        String[] items2 = {"Item3", "Item4"};
        double[] prices2 = {50, 150};
        int[] counts2 = {1, 5};
        customerMap.put(102, new Customer(102, "1234567890", items2, prices2, counts2));

        String[] items3 = {"Item5", "Item6"};
        double[] prices3 = {30, 70};
        int[] counts3 = {3, 2};
        customerMap.put(103, new Customer(103, "5432167890", items3, prices3, counts3));

        System.out.println("Displaying all customers:");
        for (Map.Entry<Integer, Customer> entry : customerMap.entrySet()) {
            entry.getValue().displayCustomer();
        }

        System.out.print("Enter Bill No to search for a customer: ");
        int searchBillNo = sc.nextInt();
        Customer searchedCustomer = customerMap.get(searchBillNo);

        if (searchedCustomer != null) {
            System.out.println("Customer details for Bill No " + searchBillNo + ":");
            searchedCustomer.displayCustomer();
        } else {
            System.out.println("No customer found with Bill No " + searchBillNo);
        }

        sc.close();
    }
}
