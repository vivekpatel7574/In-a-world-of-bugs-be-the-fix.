// 4. Sort “Student” Linked List (mentioned in Q:1) based on std_name using “Comparator”
//    interface.


import java.util.*;

class Student {
    int std_id;
    String std_name;
    int[] marks;
    int total_marks;

    public Student(int std_id, String std_name, int[] marks) {
        this.std_id = std_id;
        this.std_name = std_name;
        this.marks = marks;
        this.total_marks = calculateTotalMarks();
    }

    private int calculateTotalMarks() {
        int total = 0;
        for (int mark : marks) {
            total += mark;
        }
        return total;
    }

    public void displayStudent() {
        System.out.println("Student ID: " + std_id);
        System.out.println("Student Name: " + std_name);
        System.out.println("Total Marks: " + total_marks);
        System.out.println();
    }

    
    public String getStdName() {
        return std_name;
    }
}

class StudentNameComparator implements Comparator<Student> {
    @Override
    public int compare(Student s1, Student s2) {
        return s1.getStdName().compareTo(s2.getStdName());
    }
}

public class StudentLinkedList {
    public static void main(String[] args) {
        
        LinkedList<Student> studentList = new LinkedList<>();

        studentList.add(new Student(1, "Vivek", new int[]{85, 90, 80}));
        studentList.add(new Student(2, "Pinkal", new int[]{75, 80, 70}));
        studentList.add(new Student(3, "Keyur", new int[]{88, 92, 84}));
        studentList.add(new Student(4, "Ghanshyam", new int[]{60, 65, 70}));

        System.out.println("Students before sorting:");
        for (Student student : studentList) {
            student.displayStudent();
        }

        Collections.sort(studentList, new StudentNameComparator());

        System.out.println("Students after sorting by name:");
        for (Student student : studentList) {
            student.displayStudent();
        }
    }
}
