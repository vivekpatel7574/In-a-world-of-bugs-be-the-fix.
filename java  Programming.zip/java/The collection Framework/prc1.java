// 1. Develop a program to create Linked List for “Student” class objects references. “Student” class
//    has std_id, std_name, Array of marks, total_ marks. Calculate
//    total_marks for all students of Linked List. Display Linked List and also display a particular
//    student based on student name as a command line argument.


import java.util.LinkedList;

class Student {
    int std_id;
    String std_name;
    int[] marks;
    int total_marks;

    public Student(int std_id, String std_name, int[] marks) {
        this.std_id = std_id;
        this.std_name = std_name;
        this.marks = marks;
        this.total_marks = calculateTotalMarks();
    }

    private int calculateTotalMarks() {
        int total = 0;
        for (int mark : marks) {
            total += mark;
        }
        return total;
    }

    public void displayStudent() {
        System.out.println("Student ID: " + std_id);
        System.out.println("Student Name: " + std_name);
        System.out.println("Total Marks: " + total_marks);
        System.out.print("Marks: ");
        for (int mark : marks) {
            System.out.print(mark + " ");
        }
        System.out.println("\n");
    }


    public String getStdName() {
        return std_name;
    }
}

public class StudentLinkedList {
    public static void main(String[] args) {
        
        LinkedList<Student> studentList = new LinkedList<>();

        studentList.add(new Student(1, "Vivek", new int[]{80, 90, 85}));
        studentList.add(new Student(2, "Pinkal", new int[]{75, 88, 92}));
        studentList.add(new Student(3, "Keyur", new int[]{60, 70, 65}));
        studentList.add(new Student(4, "Ghanshyam", new int[]{95, 97, 92}));

      
        System.out.println("Displaying all students:");
        for (Student student : studentList) {
            student.displayStudent();
        }

        if (args.length > 0) {
            String searchName = args[0];
            boolean found = false;

            for (Student student : studentList) {
                if (student.getStdName().equalsIgnoreCase(searchName)) {
                    System.out.println("\nDisplaying student with name: " + searchName);
                    student.displayStudent();
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("\nStudent with name " + searchName + " not found.");
            }
        } else {
            System.out.println("\nNo student name provided in command line arguments.");
        }
    }
}
