// 2. Develop a program to create Array List for “Employee” class objects references. Employee
//    class has emp_code, emp_name, basic_sal, gross_ sal. Calculate gross_sal for all employees of
//    Array List. Display Array List and also insert an employee object reference in a particular
//    position (input) in Array List.
//    Gross_sal=basic_sal+20% of basic_sal (MA)+30% of basic_sal(HRA)



import java.util.ArrayList;
import java.util.Scanner;

class Employee {
    int emp_code;
    String emp_name;
    double basic_sal;
    double gross_sal;

    public Employee(int emp_code, String emp_name, double basic_sal) {
        this.emp_code = emp_code;
        this.emp_name = emp_name;
        this.basic_sal = basic_sal;
        this.gross_sal = calculateGrossSal();
    }

    private double calculateGrossSal() {
        double MA = 0.20 * basic_sal; 
        double HRA = 0.30 * basic_sal; 
        return basic_sal + MA + HRA;
    }

    public void displayEmployee() {
        System.out.println("Employee Code: " + emp_code);
        System.out.println("Employee Name: " + emp_name);
        System.out.println("Basic Salary: " + basic_sal);
        System.out.println("Gross Salary: " + gross_sal);
        System.out.println();
    }

    public String getEmpName() {
        return emp_name;
    }
}

public class EmployeeArrayList {
    public static void main(String[] args) {
        
        ArrayList<Employee> employeeList = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        employeeList.add(new Employee(101, "Ghanshym", 30000));
        employeeList.add(new Employee(102, "Pinkal", 25000));
        employeeList.add(new Employee(103, "Vivek", 35000));
        employeeList.add(new Employee(104, "Keyur", 40000));

        System.out.println("Displaying all employees:");
        for (Employee emp : employeeList) {
            emp.displayEmployee();
        }

        System.out.print("Enter position to insert new employee (0 to " + employeeList.size() + "): ");
        int position = sc.nextInt();

        System.out.print("Enter employee code: ");
        int emp_code = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter employee name: ");
        String emp_name = sc.nextLine();
        System.out.print("Enter basic salary: ");
        double basic_sal = sc.nextDouble();

        Employee newEmp = new Employee(emp_code, emp_name, basic_sal);
        employeeList.add(position, newEmp);

        System.out.println("\nUpdated list of employees:");
        for (Employee emp : employeeList) {
            emp.displayEmployee();
        }

        sc.close();
    }
}
