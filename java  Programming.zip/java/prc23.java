// 23 Describe abstract class called Shape which has three subclasses say Triangle, Rectangle, and
//    Circle. Define one method area () in the abstract class and override this area () in these three
//    subclasses to calculate for specific object i.e. area () of Triangle subclass should calculate area
//    of triangle etc. Same for Rectangle and Circle



abstract class Shape {
   
    public abstract double area();
}

class Triangle extends Shape {
    double base, height;

    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    @Override
    public double area() {
        return 0.5 * base * height;  
    }
}

class Rectangle extends Shape {
    double length, width;

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double area() {
        return length * width;  
    }
}


class Circle extends Shape {
    double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;  
    }
}

public class Main {
    public static void main(String[] args) {
        
        Shape triangle = new Triangle(5, 10);  
        Shape rectangle = new Rectangle(4, 6);  
        Shape circle = new Circle(7); 

        System.out.println("Area of Triangle: " + triangle.area());
        System.out.println("Area of Rectangle: " + rectangle.area());
        System.out.println("Area of Circle: " + circle.area());
    }
}
